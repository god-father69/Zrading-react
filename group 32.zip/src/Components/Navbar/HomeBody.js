import React from 'react'

export default function homeBody() {
  return (
    <div>
      
    </div>
  )
}
