export const UserData = [
  {
    id: 1,
    gain: 22,
    TradeDate: "7 Feb",
  },
  {
    id: 2,
    gain: 14,
    TradeDate: "12 Feb",
  },
  {
    id: 3,
    gain: -8,
    TradeDate: "18 Feb",
  },
  {
    id: 4,
    gain: 4,
    TradeDate: "20 Feb",
  },
  {
    id: 5,
    gain: -1.8,
    TradeDate: "24 Feb",
  },
  {
    id: 6,
    gain: 9,
    TradeDate: "30 Feb",
  },
];
